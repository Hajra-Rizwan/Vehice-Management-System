/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vms;

public class Bus extends Vehicle {
    private int seatingCapacity;

   
    public Bus(String make, String model, int year, double mileage, int seatingCapacity) {
        super(make, model, year, mileage);
        this.seatingCapacity = seatingCapacity;
    }

   
    public int getSeatingCapacity() {
        return seatingCapacity;
    }

   
    @Override
    public String getDetails() {
        return "Bus: " + getMake() + " " + getModel() + " " + getYear() + ", Mileage: " + getMileage() + ", Seating Capacity: " + seatingCapacity;
    }
}