/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vms;
public class Car extends Vehicle {
    private int numberOfDoors;

    public Car(String make, String model, int year, double mileage, int numberOfDoors) {
        super(make, model, year, mileage);
        this.numberOfDoors = numberOfDoors;
    }

   
    public int getNumberOfDoors() {
        return numberOfDoors;
    }

   
    @Override
    public String getDetails() {
        return "Car: " + getMake() + " " + getModel() + " " + getYear() + ", Mileage: " + getMileage() + ", Doors: " + numberOfDoors;
    }
}

    

