/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vms;

public class Bike extends Vehicle {
    private int biketype;

    public Bike(String make, String model, int year, double mileage, int biketype) {
        super(make, model, year, mileage);
        this.biketype = biketype;
    }

   
    public int getBikeType() {
        return biketype;
    }

   
    @Override
    public String getDetails() {
        return "Bike: " + getMake() + " " + getModel() + " " + getYear() + ", Mileage: " + getMileage() + ", Bike Type: " + getBikeType();
    }

}

