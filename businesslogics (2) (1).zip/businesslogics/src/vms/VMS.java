package vms;
import java.util.ArrayList;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import DataAccess.CarDataAccess;
import DataAccess.CustomerDataAccess;
import java.util.List;
import DataAccess.BikeDataAccess;
import DataAccess.BusDataAccess;
import DataAccess.TruckDataAccess;
             
  public class VMS {
    private static Scanner scanner = new Scanner(System.in);

   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        String username = "admin";
        String password = "123";

        int attempts = 0;
        boolean loggedIn = false;

        while (attempts < 4 && !loggedIn) {
            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();

            if (enteredUsername.equals(username) && enteredPassword.equals(password)) {
                System.out.println("Login successful!");
                loggedIn = true;
            } else {
                attempts++;
                System.out.println("Invalid username or password. Please try again.");
                System.out.println("Try again:\n " + (4 - attempts+"attempts left"));
                System.out.println();
            }
        }

        if (loggedIn) {
            boolean exit = false;

            while (!exit) {
                System.out.println("Vehicle Management System");
                System.out.println("1) Car");
                System.out.println("2) Bike");
                System.out.println("3) Truck");
                System.out.println("4) Buses");
                System.out.println("5) Exit");
                System.out.print("Choose an option: ");

                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        manageCar();
                        break;
                    case 2:
                        manageBike();
                        break;
                    case 3:
                        manageTruck();
                        break;
                    case 4:
                        manageBus();
                        break;
                    case 5: 
                        exit = true; 
                        break;
                    default:
                        System.out.println("Invalid option. Please choose again.");
                        break;
                }

                System.out.println();
            }
        } else {
            System.out.println("Maximum login attempts reached. Exiting the program.");
        }
    }
    private static void manageCar() {
        boolean exit = false;

        while (!exit) {
            System.out.println("Car Management");
            System.out.println("1) Add");
            System.out.println("2) Search");
            System.out.println("3) Remove");
            System.out.println("4) Update");
            System.out.println("5) View All");
            System.out.println("6) Back ");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); 
            switch (option) {
                case 1:
                    addCar();
                    break;
                case 2:
                    searchCar();
                    break;
                case 3:
                    removeCar();
                    break;
                case 4:
                    updateCar();
                    break;
                case 5:
                    viewAllCars();
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please choose again.");
                    break;
            }

            System.out.println();
        }
    }

    
public static void addCar() {
        System.out.println("Adding Car Information:");
        System.out.print("Enter make(brand): ");
        String make = scanner.nextLine();

        System.out.print("Enter model(version): ");
        String model = scanner.nextLine();

        System.out.print("Enter year: ");
        int year = 0;

        while (true) {
            try {
                year = scanner.nextInt();
                if (year < 1000 || year > 9999) {
                    throw new IllegalArgumentException("Invalid Year ");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. /n Try again!");
                scanner.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); 

        System.out.print("Enter mileage: ");
        double mileage = 0.0;

        while (true) {
            try {
                mileage = scanner.nextDouble();
                if (mileage <= 0) {
                    throw new IllegalArgumentException("Mileage must be a positive value.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid mileage value.");
                scanner.nextLine(); 
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine();

        System.out.print("Enter number of doors: ");
        int numberOfDoors = scanner.nextInt();
        scanner.nextLine();

        Car car = new Car(make, model, year, mileage, numberOfDoors);
         System.out.println("\n----- Customer Information -----");
        System.out.print("Enter customer first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter customer last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter customer contact number: ");
        String contactNumber = scanner.nextLine();

        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(firstName, lastName, contactNumber, email, address);
        System.out.println("----- Car Booking -----");
        System.out.println("1. Rent");
        System.out.println("2. Sale");
        System.out.println("Select an option:");
        int bookingType = scanner.nextInt();
        scanner.nextLine(); 

        switch (bookingType) {
            case 1:
               System.out.println("Rent");
                break;
            case 2:
                System.out.println("Sale");
                break;
            default:
                System.out.println("Invalid booking type.");
                break;
        }
        
        ArrayList<Car> carList = new ArrayList<>();
        carList.add(car);

       
        for (Car carObj : carList) {
            carObj.saveToFile("cardata.txt");
        }

        
       CustomerDataAccess.saveCustomerToFile(customer, "car");

    }

  
public static void searchCar() {
        CarDataAccess.searchCar();
    }
           

 public static void viewAllCars() {
        CarDataAccess.viewAllCars();
    }

 public static void removeCar() {
CarDataAccess.removeCar(); 
 }
 
 public static void updateCar() {
    System.out.print("Enter the make of the car to update: ");
    String make = scanner.nextLine();

    try {
        List<String> lines = CarDataAccess.readAllLines();

        boolean carFound = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.contains("Car: " + make)) {
                carFound = true;
                System.out.println("Updating Car: " + line);
                System.out.print("Enter new mileage: ");
                double newMileage = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                String newLine = line.replaceFirst("Mileage: \\d+", "Mileage: " + newMileage);
                lines.set(i, newLine);
            }
        }

        if (carFound) {
            CarDataAccess.writeAllLines(lines);
            System.out.println("Car updated successfully.");
        } else {
            System.out.println("Car not found.");
        }

    } catch (IOException e) {
        System.out.println("Error accessing or modifying data file: " + e.getMessage());
    }
}

 
 
private static void manageBike() {
    boolean exit = false;

    while (!exit) {
        System.out.println("Bike Management");
        System.out.println("1) Add");
        System.out.println("2) Search");
        System.out.println("3) Remove");
        System.out.println("4) Update");
        System.out.println("5) View All");
        System.out.println("6) Back ");
        System.out.print("Choose an option: ");

        int option = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (option) {
            case 1:
                addBike();
                break;
            case 2:
                searchBike();
                break;
            case 3:
                removeBike();
                break;
            case 4:
                updateBike();
                break;
            case 5:
                viewAllBikes();
                break;
            case 6:
                exit = true;
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
                break;
        }

        System.out.println();
    }
}

private static void addBike() {
    System.out.println("Adding Bike Information:");
        System.out.print("Enter make(brand):: ");
        String make = scanner.nextLine();

        System.out.print("Enter model(version):: ");
        String model = scanner.nextLine();

        System.out.print("Enter year: ");
        int year = 0;

        while (true) {
            try {
                year = scanner.nextInt();
                if (year < 1000 || year > 9999) {
                    throw new IllegalArgumentException("The year field requires  4-digit format (e.g., YYYY)");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please follow the format(YYYY)");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter mileage: ");
        double mileage = 0.0;

        while (true) {
            try {
                mileage = scanner.nextDouble();
                if (mileage <= 0) {
                    throw new IllegalArgumentException("Mileage must be a positive value.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid mileage value.");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter bike type: ");
        int bikeType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Bike bike = new Bike(make, model, year, mileage, bikeType);
         System.out.println("\n----- Customer Information -----");
        System.out.print("Enter customer first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter customer last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter customer contact number: ");
        String contactNumber = scanner.nextLine();

        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(firstName, lastName, contactNumber, email, address);

        System.out.println("----- Car Booking -----");
        System.out.println("1. Rent");
        System.out.println("2. Sale");
        System.out.println("Select an option:");
        int bookingType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

     switch (bookingType) {
            case 1:
               System.out.println("Rent");
                break;
            case 2:
                System.out.println("Sale");
                break;
            default:
                System.out.println("Invalid booking type.");
                break;
        }
 // Create an ArrayList to store car details
        ArrayList<Bike> bikeList = new ArrayList<>();
        bikeList.add(bike);

        // Save car details to file
        for (Bike bikeObj : bikeList) {
            bikeObj.saveToFile("bikedata.txt");
        }

        // Save customer details to file
        CustomerDataAccess.saveCustomerToFile(customer, "bike");

    }

  
public static void searchBike() {
        BikeDataAccess.searchBike();
    }
           

 public static void viewAllBikes() {
        BikeDataAccess.viewAllBikes();
    }

 public static void removeBike() {
BikeDataAccess.removeBike(); 
 }
 
public static void updateBike() {
    System.out.print("Enter the make of the Bike to update: ");
    String make = scanner.nextLine();

    try {
        List<String> lines = BikeDataAccess.readAllLines();

        boolean BikeFound = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.contains("Bike: " + make)) {
                BikeFound = true;
                System.out.println("Updating Bike: " + line);
                System.out.print("Enter new mileage: ");
                double newMileage = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                String newLine = line.replaceFirst("Mileage: \\d+", "Mileage: " + newMileage);
                lines.set(i, newLine);
            }
        }

        if (BikeFound) {
            BikeDataAccess.writeAllLines(lines);
            System.out.println("Bike updated successfully.");
        } else {
            System.out.println("Bike not found.");
        }

    } catch (IOException e) {
        System.out.println("Error accessing or modifying data file: " + e.getMessage());
    }
}


   

    private static void manageTruck() {
        boolean exit = false;

        while (!exit) {
            System.out.println("Truck Management");
            System.out.println("1) Add");
            System.out.println("2) Search");
            System.out.println("3) Remove");
            System.out.println("4) Update");
            System.out.println("5) View All");
            System.out.println("6) Back ");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    addTruck();
                    break;
                case 2:
                    searchTruck();
                    break;
                case 3:
                    removeTruck();
                    break;
                case 4:
                    updateTruck();
                    break;
                case 5:
                    viewAllTrucks();
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please choose again.");
                    break;
            }

            System.out.println();
        }
    }

private static void addTruck() {
        System.out.println("Adding Truck Information:");
        System.out.print("Enter make(brand):: ");
        String make = scanner.nextLine();

        System.out.print("Enter model(version):: ");
        String model = scanner.nextLine();

        System.out.print("Enter year: ");
        int year = 0;

        while (true) {
            try {
                year = scanner.nextInt();
                if (year < 1000 || year > 9999) {
                    throw new IllegalArgumentException("The year field requires  4-digit format (e.g., YYYY)");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please follow the format(YYYY)");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter mileage: ");
        double mileage = 0.0;

        while (true) {
            try {
                mileage = scanner.nextDouble();
                if (mileage <= 0) {
                    throw new IllegalArgumentException("Mileage must be a positive value.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid mileage value.");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter load capacity (in tons): ");
        double loadCapacity = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Truck truck = new Truck(make, model, year, mileage, loadCapacity);
         System.out.println("\n----- Customer Information -----");
        System.out.print("Enter customer first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter customer last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter customer contact number: ");
        String contactNumber = scanner.nextLine();

        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(firstName, lastName, contactNumber, email, address);

        System.out.println("----- Car Booking -----");
        System.out.println("1. Rent");
        System.out.println("2. Sale");
        System.out.println("Select an option:");
        int bookingType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        
            switch (bookingType) {
            case 1:
               System.out.println("Rent");
                break;
            case 2:
                System.out.println("Sale");
                break;
            default:
                System.out.println("Invalid booking type.");
                break;
        }

         // Create an ArrayList to store truck details
        ArrayList<Truck> truckList = new ArrayList<>();
        truckList.add(truck);

        // Save truck details to file
        for (Truck truckObj : truckList) {
            truckObj.saveToFile("truckdata.txt");
        }

        // Save customer details to file
        CustomerDataAccess.saveCustomerToFile(customer, "truck");

    }

  
public static void searchTruck() {
        TruckDataAccess.searchTruck();
    }
           

 public static void viewAllTrucks() {
        TruckDataAccess.viewAllTrucks();
    }

 public static void removeTruck() {
TruckDataAccess.removeTruck(); 
 }
 
public static void updateTruck() {
    System.out.print("Enter the make of the Truck to update: ");
    String make = scanner.nextLine();

    try {
        List<String> lines = TruckDataAccess.readAllLines();

        boolean TruckFound = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.contains("Truck: " + make)) {
                TruckFound = true;
                System.out.println("Updating Truck: " + line);
                System.out.print("Enter new mileage: ");
                double newMileage = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                String newLine = line.replaceFirst("Mileage: \\d+", "Mileage: " + newMileage);
                lines.set(i, newLine);
            }
        }

        if (TruckFound) {
            TruckDataAccess.writeAllLines(lines);
            System.out.println("Truck updated successfully.");
        } else {
            System.out.println("Truck not found.");
        }

    } catch (IOException e) {
        System.out.println("Error accessing or modifying data file: " + e.getMessage());
    }
}

 
 
 

private static void manageBus() {
    boolean exit = false;

    while (!exit) {
        System.out.println("Bus Management");
        System.out.println("1) Add");
        System.out.println("2) Search");
        System.out.println("3) Remove");
        System.out.println("4) Update");
        System.out.println("5) View All");
        System.out.println("6) Back ");
        System.out.print("Choose an option: ");

        int option = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (option) {
            case 1:
                addBus();
                break;
            case 2:
                searchBus();
                break;
            case 3:
                removeBus();
                break;
            case 4:
                updateBus();
                break;
            case 5:
                viewAllBuss();
                break;
            case 6:
                exit = true;
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
                break;
        }

        System.out.println();
    }
}

private static void addBus() {
     System.out.print("Enter make(brand):: ");
        String make = scanner.nextLine();

        System.out.print("Enter model(version):: ");
        String model = scanner.nextLine();

        System.out.print("Enter year: ");
        int year = 0;

        while (true) {
            try {
                year = scanner.nextInt();
                if (year < 1000 || year > 9999) {
                    throw new IllegalArgumentException("The year field requires  4-digit format (e.g., YYYY)");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please follow the format(YYYY)");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter mileage: ");
        double mileage = 0.0;

        while (true) {
            try {
                mileage = scanner.nextDouble();
                if (mileage <= 0) {
                    throw new IllegalArgumentException("Mileage must be a positive value.");
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid mileage value.");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        scanner.nextLine(); // Consume newline

        System.out.print("Enter seatingCapacity: ");
        double seatingCapacity = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Bus bus = new Bus(make, model, year, mileage, (int) seatingCapacity);
        System.out.println("\n----- Customer Information -----");

        System.out.print("Enter customer first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter customer last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter customer contact number: ");
        String contactNumber = scanner.nextLine();

        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(firstName, lastName, contactNumber, email, address);

       System.out.println("----- Car Booking -----");
        System.out.println("1. Rent");
        System.out.println("2. Sale");
        System.out.println("Select an option:");
        int bookingType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

         switch (bookingType) {
            case 1:
               System.out.println("Rent");
                break;
            case 2:
                System.out.println("Sale");
                break;
                
            default:
                System.out.println("Invalid booking type.");
                break;
        }       
// Create an ArrayList to store car details
        ArrayList<Bus> busList = new ArrayList<>();
        busList.add(bus);

        // Save car details to file
        for (Bus busObj : busList) {
            busObj.saveToFile("busdata.txt");
        }

        // Save customer details to file
       CustomerDataAccess.saveCustomerToFile(customer, "bus");

    }
  
public static void searchBus() {
        BusDataAccess.searchBus();
    }
           

 private static void viewAllBuss() {
        BusDataAccess.viewAllBuss();
    }

 public static void removeBus() {
BusDataAccess.removeBus(); 
 }
 public static void updateBus() {
    System.out.print("Enter the make of the Bus to update: ");
    String make = scanner.nextLine();

    try {
        List<String> lines = BusDataAccess.readAllLines();

        boolean BusFound = false;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.contains("Bus: " + make)) {
                BusFound = true;
                System.out.println("Updating Bus: " + line);
                System.out.print("Enter new mileage: ");
                double newMileage = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                String newLine = line.replaceFirst("Mileage: \\d+", "Mileage: " + newMileage);
                lines.set(i, newLine);
            }
        }

        if (BusFound) {
            BusDataAccess.writeAllLines(lines);
            System.out.println("Bus updated successfully.");
        } else {
            System.out.println("Bus not found.");
        }

    } catch (IOException e) {
        System.out.println("Error accessing or modifying data file: " + e.getMessage());
    }
}

 }