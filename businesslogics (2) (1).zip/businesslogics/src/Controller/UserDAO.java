/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import DataAccess.CarDataAccess;

import DataAccess.BikeDataAccess;
import DataAccess.BusDataAccess;
import DataAccess.TruckDataAccess;

/**
 *
 * @author dell
 */
public class UserDAO {
    
    
public static void searchCar() {
        CarDataAccess.searchCar();
         vms.VMS.searchCar();
    }
           

 private static void viewAllCars() {
        CarDataAccess.viewAllCars();
         vms.VMS.viewAllCars();
    }

 public static void removeCar() {
CarDataAccess.removeCar();
 vms.VMS.removeCar();
 }
  
public static void searchBike() {
        BikeDataAccess.searchBike();
        vms.VMS.searchBike();
    }
           

 private static void viewAllBikes() {
        BikeDataAccess.viewAllBikes();
        vms.VMS.viewAllBikes();
    }

 public static void removeBike() {
BikeDataAccess.removeBike(); 
vms.VMS.removeBike(); 

 }

public static void searchTruck() {
        TruckDataAccess.searchTruck();
        vms.VMS.searchTruck();
    }
           

 private static void viewAllTrucks() {
        TruckDataAccess.viewAllTrucks();
        vms.VMS.viewAllTrucks();
    }

 public static void removeTruck() {
TruckDataAccess.removeTruck(); 
vms.VMS.removeTruck();
 }
   
public static void searchBus() {
        BusDataAccess.searchBus();
        vms.VMS.searchBus();
    }
           

 private static void viewAllBuss() {
        BusDataAccess.viewAllBuss();
        vms.VMS.searchBus();
    }

 public static void removeBus() {
BusDataAccess.removeBus(); 
vms.VMS.removeBus(); 
 }

}

