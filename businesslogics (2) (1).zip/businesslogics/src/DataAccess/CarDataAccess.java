package DataAccess;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import vms.Car;

public class CarDataAccess {
    private static final String FILE_PATH = "cardata.txt";

    public static void saveCarToFile(Car car) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(car.toString());
            System.out.println("Car information saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving car information to file: " + e.getMessage());
        }
    }

    public static void removeCar(Scanner scanner) {
        try {
            List<String> lines = readAllLines();
            List<String> updatedLines = new ArrayList<>();

            System.out.print("Enter the make of the car to remove: ");
            String make = scanner.nextLine();

            boolean carFound = false;
            for (String line : lines) {
                if (!line.contains("Car: " + make)) {
                    updatedLines.add(line);
                } else {
                    carFound = true;
                    System.out.println("Removing Car: " + line);
                }
            }

            if (carFound) {
                writeAllLines(updatedLines);
                System.out.println("Car removed successfully.");
            } else {
                System.out.println("Car not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing or modifying data file: " + e.getMessage());
        }
    }

    public static void viewAllCars() {
        try {
            List<String> lines = readAllLines();

            if (!lines.isEmpty()) {
                System.out.println("----- All Cars -----");
                for (String line : lines) {
                    if (line.contains("Car:")) {
                        System.out.println(line);
                    }
                }
                System.out.println("--------------------");
            } else {
                System.out.println("No cars found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static void searchCar(Scanner scanner) {
        System.out.print("Enter make of the car to search: ");
        String make = scanner.nextLine();

        try {
            List<String> lines = readAllLines();
            boolean carFound = false;

            for (String line : lines) {
                if (line.contains("Car: " + make)) {
                    carFound = true;
                    System.out.println("Car found: " + line);
                }
            }

            if (!carFound) {
                System.out.println("Car not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static List<String> readAllLines() throws IOException {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }

        return lines;
    }

    public static void writeAllLines(List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Changes saved to file.");
        }
    }

    public static void removeCar() {
        Scanner scanner = new Scanner(System.in);
        removeCar(scanner);
    }

    public static void searchCar() {
        Scanner scanner = new Scanner(System.in);
        searchCar(scanner);
    }
}