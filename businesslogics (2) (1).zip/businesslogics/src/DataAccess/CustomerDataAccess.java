/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataAccess;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import vms.Customer;

public class CustomerDataAccess {
    public static void saveCustomerToFile(Customer customer, String vehicleType) {
        String data = "Customer: " + customer.getFirstName() + " " + customer.getLastName() + ", Contact: " + customer.getContactNumber() + "\n";
        String fileName = getFileName(vehicleType);
        Path filePath = Paths.get(fileName);

        try {
            Files.write(filePath, data.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Error saving data to file: " + e.getMessage());
        }
    }

    private static String getFileName(String vehicleType) {
        switch (vehicleType.toLowerCase()) {
            case "car":
                return "cardata.txt";
            case "bike":
                return "bikedata.txt";
            case "bus":
                return "busdata.txt";
            case "truck":
                return "truckdata.txt";
            default:
                throw new IllegalArgumentException("Invalid vehicle type.");
        }
    }
}
