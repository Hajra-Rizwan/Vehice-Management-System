package DataAccess;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import vms.Bike;

public class BikeDataAccess {
    private static final String FILE_PATH = "bikedata.txt";

    public static void saveBikeToFile(Bike bike) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(bike.toString());
            System.out.println("Bike information saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving bike information to file: " + e.getMessage());
        }
    }

    public static void removeBike(Scanner scanner) {
        try {
            List<String> lines = readAllLines();
            List<String> updatedLines = new ArrayList<>();

            System.out.print("Enter the make of the bike to remove: ");
            String make = scanner.nextLine();

            boolean bikeFound = false;
            for (String line : lines) {
                if (!line.contains("Bike: " + make)) {
                    updatedLines.add(line);
                } else {
                    bikeFound = true;
                    System.out.println("Removing Bike: " + line);
                }
            }

            if (bikeFound) {
                writeAllLines(updatedLines);
                System.out.println("Bike removed successfully.");
            } else {
                System.out.println("Bike not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing or modifying data file: " + e.getMessage());
        }
    }

    public static void viewAllBikes() {
        try {
            List<String> lines = readAllLines();

            if (!lines.isEmpty()) {
                System.out.println("----- All Bikes -----");
                for (String line : lines) {
                    if (line.contains("Bike:")) {
                        System.out.println(line);
                    }
                }
                System.out.println("--------------------");
            } else {
                System.out.println("No bikes found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static void searchBike(Scanner scanner) {
        System.out.print("Enter make of the bike to search: ");
        String make = scanner.nextLine();

        try {
            List<String> lines = readAllLines();
            boolean bikeFound = false;

            for (String line : lines) {
                if (line.contains("Bike: " + make)) {
                    bikeFound = true;
                    System.out.println("Bike found: " + line);
                }
            }

            if (!bikeFound) {
                System.out.println("Bike not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static List<String> readAllLines() throws IOException {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }

        return lines;
    }

    public static void writeAllLines(List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Changes saved to file.");
        }
    }

    public static void removeBike() {
        Scanner scanner = new Scanner(System.in);
        removeBike(scanner);
    }

    public static void searchBike() {
        Scanner scanner = new Scanner(System.in);
        searchBike(scanner);
    }
}