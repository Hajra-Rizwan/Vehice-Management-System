package DataAccess;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import vms.Bus;

public class BusDataAccess {
    private static final String FILE_PATH = "busdata.txt";

    public static void saveBusToFile(Bus bus) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(bus.toString());
            System.out.println("Bus information saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving bus information to file: " + e.getMessage());
        }
    }

    public static void removeBus(Scanner scanner) {
        try {
            List<String> lines = readAllLines();
            List<String> updatedLines = new ArrayList<>();

            System.out.print("Enter the make of the bus to remove: ");
            String make = scanner.nextLine();

            boolean busFound = false;
            for (String line : lines) {
                if (!line.contains("Bus: " + make)) {
                    updatedLines.add(line);
                } else {
                    busFound = true;
                    System.out.println("Removing Bus: " + line);
                }
            }

            if (busFound) {
                writeAllLines(updatedLines);
                System.out.println("Bus removed successfully.");
            } else {
                System.out.println("Bus not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing or modifying data file: " + e.getMessage());
        }
    }

    public static void viewAllBuss() {
        try {
            List<String> lines = readAllLines();

            if (!lines.isEmpty()) {
                System.out.println("----- All Buss -----");
                for (String line : lines) {
                    if (line.contains("Bus:")) {
                        System.out.println(line);
                    }
                }
                System.out.println("--------------------");
            } else {
                System.out.println("No buss found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static void searchBus(Scanner scanner) {
        System.out.print("Enter make of the bus to search: ");
        String make = scanner.nextLine();

        try {
            List<String> lines = readAllLines();
            boolean busFound = false;

            for (String line : lines) {
                if (line.contains("Bus: " + make)) {
                    busFound = true;
                    System.out.println("Bus found: " + line);
                }
            }

            if (!busFound) {
                System.out.println("Bus not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static List<String> readAllLines() throws IOException {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }

        return lines;
    }

    public static void writeAllLines(List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Changes saved to file.");
        }
    }

    public static void removeBus() {
        Scanner scanner = new Scanner(System.in);
        removeBus(scanner);
    }

    public static void searchBus() {
        Scanner scanner = new Scanner(System.in);
        searchBus(scanner);
    }
}