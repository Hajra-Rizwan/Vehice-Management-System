package DataAccess;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import vms.Truck;

public class TruckDataAccess {
    private static final String FILE_PATH = "truckdata.txt";

    public static void saveTruckToFile(Truck truck) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(truck.toString());
            System.out.println("Truck information saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving truck information to file: " + e.getMessage());
        }
    }

    public static void removeTruck(Scanner scanner) {
        try {
            List<String> lines = readAllLines();
            List<String> updatedLines = new ArrayList<>();

            System.out.print("Enter the make of the truck to remove: ");
            String make = scanner.nextLine();

            boolean truckFound = false;
            for (String line : lines) {
                if (!line.contains("Truck: " + make)) {
                    updatedLines.add(line);
                } else {
                    truckFound = true;
                    System.out.println("Removing Truck: " + line);
                }
            }

            if (truckFound) {
                writeAllLines(updatedLines);
                System.out.println("Truck removed successfully.");
            } else {
                System.out.println("Truck not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing or modifying data file: " + e.getMessage());
        }
    }

    public static void viewAllTrucks() {
        try {
            List<String> lines = readAllLines();

            if (!lines.isEmpty()) {
                System.out.println("----- All Trucks -----");
                for (String line : lines) {
                    if (line.contains("Truck:")) {
                        System.out.println(line);
                    }
                }
                System.out.println("--------------------");
            } else {
                System.out.println("No trucks found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static void searchTruck(Scanner scanner) {
        System.out.print("Enter make of the truck to search: ");
        String make = scanner.nextLine();

        try {
            List<String> lines = readAllLines();
            boolean truckFound = false;

            for (String line : lines) {
                if (line.contains("Truck: " + make)) {
                    truckFound = true;
                    System.out.println("Truck found: " + line);
                }
            }

            if (!truckFound) {
                System.out.println("Truck not found.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing data file: " + e.getMessage());
        }
    }

    public static List<String> readAllLines() throws IOException {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }

        return lines;
    }

    public static void writeAllLines(List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Changes saved to file.");
        }
    }

    public static void removeTruck() {
        Scanner scanner = new Scanner(System.in);
        removeTruck(scanner);
    }

    public static void searchTruck() {
        Scanner scanner = new Scanner(System.in);
        searchTruck(scanner);
    }
}